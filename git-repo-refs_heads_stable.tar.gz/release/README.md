These are helper tools for managing official releases.
See the [release process](../docs/release-process.md) document for more details.
